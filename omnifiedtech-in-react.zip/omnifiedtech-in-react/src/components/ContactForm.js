import React, { Component } from "react";
import * as emailjs from "emailjs-com";
import "./contact.css";
import SkyLight from "react-skylight";
const service_id = "default_service";
const template_id = "omnitech";
const user_id = "user_1WwJQ0R1tx6phRJeNZZP8";
const popupStyle = {
  backgroundColor: "#ffffff",
  minHeight: "200px"
};
class ContactForm extends Component {
  constructor(props) {
    super(props);
    this.state = { name: "", email: "", message: "", popupText: "x" };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange = e => {
    this.setState({ [e.target.name]: e.target.value });
  };

  handleSubmit(e) {
    e.preventDefault();
    var template_params = {
      name: this.state.name,
      email: this.state.email,
      message: this.state.message
    };
    emailjs.send(service_id, template_id, template_params, user_id).then(
      response => {
        console.log("SUCCESS!", response.status, response.text);
        this.setState(
          { popupText: "Success! We will get back to you shortly" },
          this.popupT.show()
        );
      },
      err => {
        console.log("FAILED...", err);
        this.setState(
          { popupText: "ummm, that didn't quite work. Try again?" },
          this.popupT.show()
        );
      }
    );
  }
  render() {
    return (
      <div>
        <SkyLight
          closeButtonStyle={{ color: "#000" }}
          dialogStyles={popupStyle}
          hideOnOverlayClicked
          ref={ref => (this.popupT = ref)}
          title={this.state.popupText}
        />

        <form onSubmit={e => this.handleSubmit(e)} id="contactForm">
          <input
            name="name"
            type="text"
            className="field"
            placeholder="name"
            onChange={this.handleChange}
          />
          <input
            name="email"
            type="email"
            className="field"
            placeholder="email"
            onChange={this.handleChange}
          />
          <textarea
            name="message"
            className="field"
            id="message"
            placeholder="message"
            onChange={this.handleChange}
          />
          <input className="contactbutt" type="submit" value="Contact Us!" />
        </form>
        <br />
      </div>
    );
  }
}
export default ContactForm;
