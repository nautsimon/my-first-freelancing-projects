import React, { Component } from "react";
import ReactDOM from "react-dom";

import ContactForm from "./components/ContactForm";
import rocket from "./img/rocket.png";
import landingImg from "./img/titleimg.png";
import pesto from "./img/pesto.PNG";
import orion from "./img/orion.png";
import minithon from "./img/minithon.png";
import academia from "./img/academia.png";
import microdot from "./img/microdot.png";
import communique from "./img/thecc.PNG";

import bike from "./img/bike.png";
import ghana from "./img/ghana.png";
import markov from "./img/markov.png";

import center from "./img/center.png";
import ckage from "./img/ckage.png";
import rdrc from "./img/rdrc.PNG";

import fspace from "./img/fspace.PNG";
import fractal from "./img/fractal.png";
import corn from "./img/corn.PNG";
import root from "./img/root.PNG";

import ben from "./img/ben.png";
import simon from "./img/simons-min.png";
import git from "./img/git.png";
import logo from "./img/logo.png";
import reactIco from "./img/reactIco.png";
import awsIco from "./img/awsIco.png";
import analyticsIco from "./img/googleAIco.png";
import crossCompIco from "./img/crosscIco.png";
import iosIco from "./img/iosIco.png";
import miscIco from "./img/miscIco.png";
import "./index.css";
import Tools from "./components/Tools";
import SkyLight from "react-skylight";

import { BrowserRouter as Router } from "react-router-dom";
import Route from "react-router-dom/Route";

const popupStyle = {
  backgroundColor: "#ffffff",
  minHeight: "200px",
  minWidth: "400px"
};
class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      filter: 0
    };
    this.handleScroll = this.handleScroll.bind(this);
    this.handleFilter = this.handleFilter.bind(this);
    this.handleForm = this.handleForm.bind(this);
  }
  componentDidMount() {
    window.addEventListener("scroll", this.handleScroll);
  }

  componentWillUnmount() {
    window.removeEventListener("scroll", this.handleScroll);
  }
  handleScroll() {
    if (window.scrollY < 50) {
      this.setState({ backgroundC: "rgba(0, 0, 0, 0.0)" });
      console.log("yuh", this.state.isTop);
    } else if (window.scrollY >= 50) {
      this.setState({ backgroundC: "rgba(0, 0, 0, 0.5)" });
      console.log("yuh", this.state.isTop);
    }
  }
  handleForm(e) {
    e.preventDefault();

    var req =
      "name=" +
      document.getElementById("name").value +
      "&" +
      "email=" +
      document.getElementById("email").value +
      "&" +
      "text=" +
      document.getElementById("message").value;

    var http = new XMLHttpRequest();
    http.open("POST", "/contact", true);
    http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    http.onreadystatechange = function() {
      if (http.readyState === 4 && http.status === 200) {
        this.thankPop.show();
      }
    };

    http.send(req);
    this.thankPop.show();
  }
  handleFilter(filterNum) {
    this.setState({ filter: filterNum });
  }
  render() {
    return (
      <Router>
        <div className="app">
          <SkyLight
            closeButtonStyle={{ color: "#000" }}
            dialogStyles={popupStyle}
            hideOnOverlayClicked
            ref={ref => (this.thankPop = ref)}
            title="Thank You!"
          >
            We will get back to you shortly
          </SkyLight>
          <Route
            path="/"
            exact
            strict
            render={() => {
              return (
                <div>
                  <div>
                    <img
                      src={landingImg}
                      className="titleimg fadeIn"
                      alt="land"
                    />
                    <div className="sect sectOne fadeIn" />
                    <div className="mainbody">
                      <div className="row">
                        <div className="column leftr">
                          <h1 className="titles" id="top">
                            Elevate your Endeavour
                          </h1>
                          <p>
                            The manifestation of an idea is one of the most
                            powerful things a human being can do. At Omnified
                            Tech, we aim to bring your ideas to life through the
                            power of web/application development. Let us help
                            you share your great ideas with the world. From
                            brainstorming to making your site a live page on the
                            internet: we are here for you.
                          </p>
                        </div>
                        <div className="column rightr">
                          <div className="centerimages">
                            <img
                              data-aos="fade-up"
                              data-aos-duration="00"
                              className="rocket"
                              alt="rocket"
                              src={rocket}
                            />
                          </div>
                        </div>
                      </div>
                      <h1 className="spacetoph1 spacebottom">
                        Previous Projects
                      </h1>
                    </div>
                    <div className="row">
                      <div className="column projectsCol">
                        <div className="centerimages">
                          <div className="container">
                            <img
                              data-aos="fade-up"
                              data-aos-duration="1000"
                              src={pesto}
                              alt="pesto"
                              className="blockpics"
                            />
                            <a
                              href="https://chrome.google.com/webstore/detail/pesto-aioli/baalpccnhigkkjhdaacgbkfopdcpbemp"
                              className="hovereffect"
                            >
                              <div className="text">See Project</div>
                            </a>
                          </div>
                          <div className="container">
                            <img
                              data-aos="fade-up"
                              data-aos-duration="1000"
                              src={corn}
                              alt="corn"
                              className="blockpics"
                            />
                            <a
                              href="https://cookedcorn.casa"
                              className="hovereffect"
                            >
                              <div className="text">See Project</div>
                            </a>
                          </div>
                          <div className="container">
                            <img
                              data-aos="fade-up"
                              data-aos-duration="1000"
                              src={academia}
                              alt="dr"
                              className="blockpics"
                            />
                            <a
                              href="https://stemdominicana.com/"
                              className="hovereffect"
                            >
                              <div className="text">See Project</div>
                            </a>
                          </div>
                          <div className="container">
                            <img
                              data-aos="fade-up"
                              data-aos-duration="1000"
                              src={ghana}
                              alt="dr"
                              className="blockpics"
                            />
                            <a
                              href="https://buildabotghana.com/"
                              className="hovereffect"
                            >
                              <div className="text">See Project</div>
                            </a>
                          </div>
                          <div className="container">
                            <img
                              data-aos="fade-up"
                              data-aos-duration="1000"
                              src={microdot}
                              alt="microdot"
                              className="blockpics"
                            />
                            <a
                              href="https://github.com/simonmahns/microdot"
                              className="hovereffect"
                            >
                              <div className="text">See Project</div>
                            </a>
                          </div>
                        </div>
                      </div>
                      <div className="column projectsCol">
                        <div className="container">
                          <img
                            data-aos="fade-up"
                            data-aos-duration="1000"
                            src={fractal}
                            alt="fractal"
                            className="blockpics"
                          />
                          <a
                            href="https://github.com/simonmahns/fractal"
                            className="hovereffect"
                          >
                            <div className="text">See Project</div>
                          </a>
                        </div>
                        <div className="centerimages">
                          <div className="container">
                            <img
                              data-aos="fade-up"
                              data-aos-duration="1500"
                              src={communique}
                              alt="communique"
                              className="blockpics"
                            />
                            <a
                              href="https://www.theccnewsletter.com/"
                              className="hovereffect"
                            >
                              <div className="text">See Project</div>
                            </a>
                          </div>
                          <div className="container">
                            <img
                              data-aos="fade-up"
                              data-aos-duration="1500"
                              src={fspace}
                              alt="fspace"
                              className="blockpics"
                            />
                            <a
                              href="https://fspace.tech/"
                              className="hovereffect"
                            >
                              <div className="text">See Project</div>
                            </a>
                          </div>
                          <div className="container">
                            <img
                              data-aos="fade-up"
                              data-aos-duration="1500"
                              src={ckage}
                              alt="ckage"
                              className="blockpics"
                            />
                            <a
                              href="https://github.com/omnifiedtechnologies/ckage"
                              className="hovereffect"
                            >
                              <div className="text">See Project</div>
                            </a>
                          </div>
                        </div>
                        <div className="container">
                          <img
                            data-aos="fade-up"
                            data-aos-duration="1000"
                            src={markov}
                            alt="dr"
                            className="blockpics"
                          />
                          <a href="www.tweetgen.xyz" className="hovereffect">
                            <div className="text">See Project</div>
                          </a>
                        </div>
                        <div className="container">
                          <img
                            data-aos="fade-up"
                            data-aos-duration="1500"
                            src={center}
                            alt="center"
                            className="blockpics"
                          />
                          <a
                            onclick="scrollToDiv('contactUs')"
                            className="hovereffect"
                          >
                            <div className="text">Get a Free Quote</div>
                          </a>
                        </div>
                      </div>
                      <div className="column projectsCol">
                        <div className="container">
                          <img
                            data-aos="fade-up"
                            data-aos-duration="1000"
                            src={root}
                            alt="root"
                            className="blockpics"
                          />
                          <a
                            href="https://rootcellar.tech"
                            className="hovereffect"
                          >
                            <div className="text">See Project</div>
                          </a>
                        </div>
                        <div className="container">
                          <img
                            data-aos="fade-up"
                            data-aos-duration="2000"
                            src={rdrc}
                            alt="rdrc"
                            className="blockpics"
                          />
                          <a
                            href="https://rdrecicla.com/"
                            className="hovereffect"
                          >
                            <div className="text">See Project</div>
                          </a>
                        </div>
                        <div className="container">
                          <img
                            data-aos="fade-up"
                            data-aos-duration="1000"
                            src={bike}
                            alt="dr"
                            className="blockpics"
                          />
                          <a
                            href="https://cookedcorn.casa/bike"
                            className="hovereffect"
                          >
                            <div className="text">See Project</div>
                          </a>
                        </div>
                        <div className="container">
                          <img
                            data-aos="fade-up"
                            data-aos-duration="2000"
                            src={minithon}
                            alt="minithon"
                            className="blockpics"
                          />
                          <a
                            href="http://uhsminithon.com/"
                            className="hovereffect"
                          >
                            <div className="text">See Project</div>
                          </a>
                        </div>
                        <div className="container">
                          <img
                            data-aos="fade-up"
                            data-aos-duration="2000"
                            src={orion}
                            alt="orion"
                            className="blockpics"
                          />
                          <a
                            href="http://omnified.org/"
                            className="hovereffect"
                          >
                            <div className="text">See Project</div>
                          </a>
                        </div>
                      </div>
                    </div>
                    <div className="mainbody">
                      <h1 className="spacetoph1 spacebottom">
                        Tools and Capabilities
                      </h1>
                      <div className="toolsDiv">
                        <ul className="toolsUl">
                          <li className="toolsLi">
                            <div className="liDiv">
                              <img
                                src={reactIco}
                                className="toolIco"
                                alt="react"
                                onClick={() => this.handleFilter(0)}
                              />
                            </div>
                          </li>

                          <li className="toolsLi">
                            <div className="liDiv">
                              <img
                                src={awsIco}
                                className="toolIco"
                                alt="aws"
                                onClick={() => this.handleFilter(1)}
                              />
                            </div>
                          </li>

                          <li className="toolsLi">
                            <div className="liDiv">
                              <img
                                src={crossCompIco}
                                className="toolIco"
                                alt="crossComp"
                                onClick={() => this.handleFilter(2)}
                              />
                            </div>
                          </li>

                          <li className="toolsLi">
                            <div className="liDiv">
                              <img
                                src={iosIco}
                                className="toolIco"
                                alt="ios"
                                onClick={() => this.handleFilter(3)}
                              />
                            </div>
                          </li>

                          <li className="toolsLi">
                            <div className="liDiv">
                              <img
                                src={analyticsIco}
                                className="toolIco"
                                alt="analytics"
                                onClick={() => this.handleFilter(4)}
                              />
                            </div>
                          </li>

                          <li className="toolsLi">
                            <div className="liDiv">
                              <img
                                src={miscIco}
                                className="toolIco"
                                alt="misc"
                                onClick={() => this.handleFilter(5)}
                              />
                            </div>
                          </li>
                        </ul>
                        <Tools filter={this.state.filter} />
                      </div>

                      <h1 className="spacetoph1">The Team</h1>
                      <div className="row">
                        <div className="biocolumn">
                          <div className="centerimages">
                            <a href="https://www.linkedin.com/in/ben-g-78a55b145/?originalSubdomain=uk">
                              <img src={ben} className="biopic" alt="ben" />
                            </a>
                            <h5>Ben</h5>
                            <p>
                              Ben is majoring in Computer Science at UMBC and is
                              a engineer at Contrast Security. A 4 year full
                              stack developer with a fortes in backend
                              development, C, and node.
                            </p>
                            <a href="https://github.com/avuxo">
                              <img src={git} className="gitpic" alt="git" />
                            </a>
                          </div>
                        </div>
                        <div className="biocolumn">
                          <div className="centerimages">
                            <a href="https://www.linkedin.com/in/simon-mahns-30bb5a144">
                              <img src={simon} className="biopic" alt="simon" />
                            </a>
                            <h5>Simon</h5>
                            <p className="formattexts">
                              Simon is majoring in Computer Science and minoring
                              Astrophysics at the University of Chicago. A 3
                              year full stack developer with fortes in frontend
                              development, aws, and ios development.
                            </p>
                            <a href="https://github.com/simonmahns">
                              <img src={git} className="gitpic" alt="git" />
                            </a>
                          </div>
                        </div>
                      </div>
                      <h1 className="spacetoph1" id="contactUs">
                        Contact us
                      </h1>
                      <div className="row">
                        <div className="contactcolumn west">
                          <div className="formWrapper">
                            <ContactForm />
                            <br />
                          </div>
                        </div>
                        <div className="contactcolumn south">
                          <div className="formatdiv">
                            <p> contact@omnifiedtech.com</p>
                            <h4>Things your inquiry should include:</h4>
                            <li># Time Frame</li>
                            <li># A title for your project</li>
                            <li>
                              # What type of site (educational, shopping,
                              informational, static, gaming, etc.)
                            </li>
                            <li># Brief summary of the site</li>
                            <li># Any questions you may have</li>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="subSection" />

                    <div className="sect sectTwo" />
                    <footer>
                      <img
                        onclick="scrollToDiv('top')"
                        src={logo}
                        class="footerimages"
                        alt="footerImg"
                      />
                      <p>Omnified Technologies LLC 2018 </p>
                    </footer>
                  </div>
                </div>
              );
            }}
          />
        </div>
      </Router>
    );
  }
}

export default App;

ReactDOM.render(<App />, document.getElementById("root"));
