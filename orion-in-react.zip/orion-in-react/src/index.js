import React, { Component } from "react";
import ReactDOM from "react-dom";
import orionLogo from "./img/orionlogowhite.png";
import ghanafront from "./img/ghanafront.PNG";
import princeton from "./img/princeton.png";
import walmart from "./img/walmart.png";
import uth from "./img/uth.png";

import "./index.css";
import Other from "./components/Other";
import Stemdominicana from "./components/Stemdominicana";
import Donate from "./components/Donate";
import Fspace from "./components/Fspace";
import Ghana from "./components/Ghana";
import Footer from "./components/Footer";

import { BrowserRouter as Router, Link } from "react-router-dom";
import Route from "react-router-dom/Route";
import About from "./components/About";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      backgroundC: "rgba(0, 0, 0, 0.0)"
    };
    this.handleScroll = this.handleScroll.bind(this);
  }
  componentDidMount() {
    window.addEventListener("scroll", this.handleScroll);
  }

  componentWillUnmount() {
    window.removeEventListener("scroll", this.handleScroll);
  }
  handleScroll() {
    if (window.scrollY < 50) {
      this.setState({ backgroundC: "rgba(0, 0, 0, 0.0)" });
      console.log("yuh", this.state.isTop);
    } else if (window.scrollY >= 50) {
      this.setState({ backgroundC: "rgba(0, 0, 0, 0.5)" });
      console.log("yuh", this.state.isTop);
    }
  }
  handleFooter() {
    this.setState({ footerStyle: "#888888" });
  }
  render() {
    return (
      <Router>
        <div className="app">
          <header style={{ backgroundColor: this.state.backgroundC }}>
            <div id="nav-placeholder" />
            <div className="header">
              <a href="">
                <Link className="reactLink" to="/">
                  <img
                    src={orionLogo}
                    id="fading"
                    alt="logo"
                    className="logo"
                  />
                </Link>
              </a>

              <nav>
                <input
                  type="checkbox"
                  id="css-toggle-menu"
                  name="css-toggle-menu"
                  checked="false"
                />
                <ul className="main">
                  <li>
                    <Link className="reactLink" to="/fspace">
                      <a href="">F[Space]</a>
                    </Link>
                  </li>
                  <li>
                    <Link className="reactLink" to="/stemdominicana">
                      <a href="">STEM Dominicana</a>
                    </Link>
                  </li>
                  <li>
                    <Link className="reactLink" to="/ghana">
                      <a href="">Ghana</a>
                    </Link>
                  </li>
                  <li>
                    <Link className="reactLink" to="/other">
                      <a href="">Other</a>
                    </Link>
                  </li>
                  <li>
                    <Link className="reactLink" to="/about">
                      <a href="">About</a>
                    </Link>
                  </li>
                </ul>
                <label htmlFor="css-toggle-menu" id="css-toggle-menu">
                  <span className="navicon" />
                </label>
              </nav>
            </div>
          </header>
          <Route
            path="/"
            exact
            strict
            render={() => {
              return (
                <div>
                  <h1 className="titlepagetext" role="navigation">
                    INNOVATION IS FOR EVERYONE
                  </h1>
                  <div className="sect sectOne" />
                  <div className="one">
                    <div className="mainbody">
                      <div className="row">
                        <div className="left column">
                          <h2>Facilitating the Future</h2>
                          <p>
                            ORION is a US based nonprofit (501c3) dedicated to
                            providing a wide assortment of STEM oriented
                            education resources, from mentors to grant money,
                            for both organizations and students. Our nonprofit
                            team consists of self-starters and passionate hard
                            workers, some of which are studying at the nation’s
                            most prestigious colleges. Regardless of what
                            institution we hail from, we are united by our
                            universal motivation to help students realize their
                            full potential and to create environments where
                            innovation and invention can be easily cultivated.{" "}
                            <br />
                            <br />
                            Enough with the boring stuff, check out our cool
                            projects!
                            <br />
                            <i>
                              In the menu you will find our larger scale
                              projects, which are managed by committees within
                              the nonprofit. To see our smaller projects and
                              others, check "other"
                            </i>
                          </p>
                        </div>
                        <div className="right column">
                          <div className="centerimages">
                            <img
                              src={ghanafront}
                              className="imageright"
                              alt="frontimg"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="two">
                    <div className="mainbody">
                      <div className="sponsordiv">
                        <p className="">Sponsors/Partners</p>
                        <img
                          src={princeton}
                          alt="sponsor"
                          className="sponsor"
                        />
                        <img src={walmart} alt="sponsor" className="sponsor" />
                        <img src={uth} alt="sponsor" className="sponsor" />
                      </div>
                    </div>
                  </div>
                  <Footer color={"transparent"} />
                </div>
              );
            }}
          />
          <Route
            path="/donate"
            exact
            strict
            render={() => {
              return <Donate />;
            }}
          />
          <Route
            path="/fspace"
            exact
            strict
            render={() => {
              return <Fspace />;
            }}
          />
          <Route
            path="/stemdominicana"
            exact
            strict
            render={() => {
              return <Stemdominicana />;
            }}
          />
          <Route
            path="/ghana"
            exact
            strict
            render={() => {
              return <Ghana />;
            }}
          />

          <Route
            path="/other"
            exact
            strict
            render={() => {
              return <Other />;
            }}
          />
          <Route
            path="/about"
            exact
            strict
            render={() => {
              return <About />;
            }}
          />
        </div>
      </Router>
    );
  }
}

export default App;

ReactDOM.render(<App />, document.getElementById("root"));
