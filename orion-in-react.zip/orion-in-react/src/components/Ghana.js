import React, { Component } from "react";
import Footer from "./Footer";
import ghanaText from "../img/ghanatextw.png";
import ghanamain from "../img/ghanamain.PNG";

class Ghana extends Component {
  render() {
    return (
      <div>
        <img src={ghanaText} alt="college" class="ghanaimg" />
        <div class="sect sectFive" />
        <div class="six">
          <div class="mainbody">
            <div class="row">
              <div class="left column">
                <h2 class="textwhite">Ghana's next generation</h2>
                <p class="textwhite">
                  STEM Ghana is a committee tasked with running STEM camps in
                  Accra, Ghana. This summer Simon Mahns and Jude Abijah raised
                  over 2200$ for this project. For the final two weeks of July,
                  Simon, along with instructors from STEMBees, a Ghanaian
                  nonprofit that we collaborated closely with, completed a
                  robotics camp. Kits were donated to STEMBees upon completion.{" "}
                  <br />
                  <br />
                  To learn more about the STEMBees, check out their{" "}
                  <a className="ghanalink" href="http://www.stembees.org/">
                    website
                  </a>
                </p>
              </div>
              <div class="right column">
                <div class="centerimages">
                  <img src={ghanamain} class="imageright" alt="stemBees" />
                </div>
              </div>
            </div>
          </div>
        </div>
        <Footer color={"#cc1225"} />
      </div>
    );
  }
}
export default Ghana;
