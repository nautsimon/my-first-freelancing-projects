import React, { Component } from "react";
import { Link } from "react-router-dom";
import face from "../img/face.png";
import insta from "../img/insta.png";
import twitter from "../img/twitter.png";
import "./footer.css";
class Footer extends Component {
  constructor(props) {
    super(props);
    this.handleColor = this.handleColor.bind(this);
  }
  handleColor(color) {
    return (
      <div className="footerDiv" style={{ backgroundColor: color }}>
        <div className="footerCol">
          <div className="footleft column">
            <div className="paypal">
              <form
                action="https://www.paypal.com/cgi-bin/webscr"
                method="post"
                target="_top"
              >
                <input type="hidden" name="cmd" value="_s-xclick" />
                <input
                  type="hidden"
                  name="hosted_button_id"
                  value="MWBQFPXHEY2XS"
                />
                <input
                  type="image"
                  src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif"
                  border="0"
                  name="submit"
                  alt="PayPal - The safer, easier way to pay online!"
                />
                <img
                  alt=""
                  border="0"
                  src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif"
                  width="1"
                  height="1"
                />
              </form>
            </div>
          </div>
          <div className="footright column">
            <br />

            <Link className="blacktextlink" to="/donate">
              <p>Donation Information</p>
            </Link>
            <p>Contact us at outreach@omnified.org</p>
          </div>
        </div>
        <div className="logoDiv">
          <span className="footLogos">
            <a href="https://www.instagram.com/orionnpo/">
              <img src={insta} alt="resource" className="logoTiles" />
            </a>
            <a href="https://twitter.com/fredmdspace">
              <img src={twitter} alt="resource" className="logoTiles" />
            </a>
            <a href="https://www.facebook.com/frederickmdspace/">
              <img src={face} alt="resource" className="logoTiles" />
            </a>
          </span>
        </div>
      </div>
    );
  }
  render() {
    var color = this.props.color;
    console.log(color);
    var footer = this.handleColor(color);
    return <div>{footer}</div>;
  }
}
export default Footer;
