import React, { Component } from "react";
import stemdrr from "../img/stemdrr.PNG";
import drstem from "../img/drstem.jpg";
import Footer from "./Footer";

class Stemdominicana extends Component {
  render() {
    return (
      <div>
        <img src={stemdrr} alt="fspace" className="fspaceimg" />
        <div className="sect sectFour" />
        <div className="five">
          <div className="mainbody">
            <div className="row">
              <div className="left column">
                <h2 className="whitetext">Supporting tomorrow's leaders</h2>
                <p className="whitetext">
                  STEM Dominicana is a ORION comittee dedicated to promoting
                  STEM education in the Dominican Republic. STEM Dominicana has
                  successfully led two consecutive years of Academia Robotica, a
                  robotics camp based in Santo Domingo in collaboration with
                  Princeton University and JPAL-LAC. This camp has taught Lego
                  robotics, scratch, circuitry, and Arduino programming to a
                  select group pf public high school kids. This camp is an
                  all-expenses paid experience for the students. Additionally,
                  Princeton University and The Abdul Latif Jameel Poverty Action
                  Lab are working with ORION to collect data about the
                  happenings within the camp, such as teamwork dynamics and
                  teaching methods.
                  <br />
                  STEM Dominicana is also starting a Youtube chanel where
                  various instructional/advisory videos and podcasts will be
                  posted.
                  <br /> <br />
                  Visit the STEM Dominicana{" "}
                  <a className="stemdrLink" href="https://stemdominicana.com/">
                    website
                  </a>
                </p>
              </div>
              <div className="right column">
                <div className="centerimages">
                  <img src={drstem} className="imageright" alt="imgright" />
                </div>
              </div>
            </div>
          </div>
        </div>
        <Footer color={"#1d48ea"} />
      </div>
    );
  }
}
export default Stemdominicana;
