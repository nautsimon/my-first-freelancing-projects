import React, { Component } from "react";
import orionw from "../img/orionw.png";
import andrew from "../img/andrew.png";
import ben from "../img/ben.png";
import maxine from "../img/maxine.PNG";
import nick from "../img/nick.PNG";
import noah from "../img/noah.png";
import jude from "../img/jude.png";
import robert from "../img/robert.PNG";

import simon3 from "../img/simoncircle.png";
import Footer from "./Footer";
class About extends Component {
  render() {
    return (
      <div>
        <img src={orionw} alt="college" className="orionimg" />
        <div className="sect sectOne" />
        <div className="mainbody">
          <h2>About us</h2>
          <p>
            ORION was created in 2017 initially as a way to raise money for The
            Mandelbots, a first-year robotics team based in the Urbana, Maryland
            area. What initially began as a group of broke high schoolers trying
            to buy parts and tools to play with, began to grow over the summer
            of 2017, as the nonprofit collaborated with Princeton and The Abdul
            Latif Jameel Poverty Action Lab to conduct a study and create
            Academia Robotica. Since then, ORION has continued to embark on
            numerous projects, such as creating FLL teams and trying to qualify
            a team for the Lemelson-MIT engineering challenge. As ORION
            continues to expand, the ORION team does as well, filling itself
            with a diverse array of students and professionals universally
            motivated to help students all around the world realize their full
            potential.
            <br />
            <br />
            What’s up with our name?
            <br />
            ORION is formally known as Omnified Resources for Innovation and
            Cognition, Corp. ORION is an acronym for this lengthy moniker, with
            the last two letters of cognition, “on”, representing the “on” of
            ORION
            <br />
            <br />
            Code for this site:
            <br />
            <a
              className="blacktextlink"
              href="https://github.com/simonmahns/orion-in-react"
            >
              https://github.com/simonmahns/orion-in-react
            </a>
            <br />
            View the Board of Directors and their linkedin/Social media profiles
            below.
            <br /> *Big thanks to legacy member, Harry Diao, for helping found
            this nonprofit*
          </p>
        </div>
        <div className="rowouterdiv">
          <div className="row">
            {/* <!--LEFT COLUMN-->   */}
            <div className="column bioCol">
              <div className="container1">
                <img
                  data-aos="fade-up"
                  data-aos-duration="1000"
                  src={simon3}
                  alt="simon"
                  className="biopics"
                />
                <a href="#contactloc" className="hovereffect">
                  <div
                    className="textbio"
                    href="https://www.linkedin.com/in/simon-mahns-30bb5a144/"
                  >
                    Simon Mahns: President | Founder{" "}
                  </div>
                </a>
              </div>
              <div className="container1">
                <img
                  data-aos="fade-up"
                  data-aos-duration="1500"
                  src={nick}
                  alt="nick"
                  className="biopics"
                />
                <a href="#contactloc" className="hovereffect">
                  <div
                    className="textbio"
                    href="https://www.linkedin.com/in/nicholas-pinto-a50b19131/"
                  >
                    Nick Pinto: Secretary | Founder
                  </div>
                </a>
              </div>
              <div className="container1">
                <img
                  data-aos="fade-up"
                  data-aos-duration="1500"
                  src={robert}
                  alt="robert"
                  className="biopics"
                />
                <a href="#contactloc" className="hovereffect">
                  <div
                    className="textbio"
                    href="https://www.instagram.com/bobandrew2002/"
                  >
                    Roberto Herrara: STEM dominicana{" "}
                  </div>
                </a>
              </div>
            </div>
            {/* <!--MIDDLE COLUMN--> */}
            <div className="column bioCol">
              <div className="container1">
                <img
                  data-aos="fade-up"
                  data-aos-duration="1500"
                  src={ben}
                  alt="ben"
                  className="biopics"
                />
                <a href="#contactloc" className="hovereffect">
                  <div
                    className="textbio"
                    href="https://www.linkedin.com/in/ben-g-78a55b145/"
                  >
                    Ben Greenberg: Vice President{" "}
                  </div>
                </a>
              </div>
              <div className="container1">
                <img
                  data-aos="fade-up"
                  data-aos-duration="1500"
                  src={maxine}
                  alt="maxine"
                  className="biopics"
                />
                <a href="#contactloc" className="hovereffect">
                  <div
                    className="textbio"
                    href="https://www.linkedin.com/in/maxine-vidal-6a5048144/"
                  >
                    Maxine: Outreach
                  </div>
                </a>
              </div>
            </div>
            {/* <!--RIGHT COLUMN--> */}
            <div className="column bioCol">
              <div className="container1">
                <img
                  data-aos="fade-up"
                  data-aos-duration="1500"
                  src={noah}
                  alt="noah"
                  className="biopics"
                />
                <a href="#contactloc" className="hovereffect">
                  <div
                    className="textbio"
                    href="https://twitter.com/ShrimpSmith"
                  >
                    Noah Cooper: Treasurer{" "}
                  </div>
                </a>
              </div>
              <div className="container1">
                <img
                  data-aos="fade-up"
                  data-aos-duration="1500"
                  src={andrew}
                  alt="andrew"
                  className="biopics"
                />
                <a href="#contactloc" className="hovereffect">
                  <div
                    className="textbio"
                    href="https://www.facebook.com/andrew.church.14?ref=br_rs"
                  >
                    Andrew Church: F[space]{" "}
                  </div>
                </a>
              </div>
              <div className="container1">
                <img
                  data-aos="fade-up"
                  data-aos-duration="1500"
                  src={jude}
                  alt="jude"
                  className="biopics"
                />
                <a href="#contactloc" className="hovereffect">
                  <div
                    className="textbio"
                    href="https://www.instagram.com/judeabijah/"
                  >
                    Jude Abijah: Ghana{" "}
                  </div>
                </a>
              </div>
            </div>
          </div>
        </div>

        <Footer color={"transparent"} />
      </div>
    );
  }
}
export default About;
