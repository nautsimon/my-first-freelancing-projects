import React, { Component } from "react";
import ckage from "../img/fspace.png";
import fspacepic from "../img/fspace.JPG";
import Footer from "./Footer";

class Other extends Component {
  render() {
    return (
      <div>
        <img src={ckage} alt="fspace" className="fspaceimg" />
        <div className="sect sectThree" />
        <div className="four">
          <div className="mainbody">
            <div className="row">
              <div className="left column">
                <h2 className="whitetext">More than a Makerspace</h2>
                <p className="whitetext">
                  Located at 151 W Patrick Street, F[Space] was a
                  Makerspace/Hackerspace dedicated to providing various
                  prototyping resources. F[Space] sought to be a collaboration
                  space, one where STEM communities throughout Maryland could
                  share projects and help educate others of their endeavors.
                  F[Space] also hosted bi-monthly classes and talks as well as
                  weekly game nights/locksport on Wednesday evenings. Currently
                  Simon is working with FITCI to develop a Makerspace on Market
                  Street.
                  <br /> <br />
                  To see previous meeting dates, check out our{" "}
                  <a
                    className="fspacelink"
                    href="https://www.meetup.com/FSpace/"
                  >
                    meetup
                  </a>
                  <br />
                  Visit the F[Space]{" "}
                  <a className="fspacelink" href="https://fspace.tech">
                    website
                  </a>
                </p>
              </div>
              <div className="right column">
                <div className="centerimages">
                  <img src={fspacepic} className="imageright" alt="fspace" />
                </div>
              </div>
            </div>
          </div>
        </div>
        <Footer color={"#008000"} />
      </div>
    );
  }
}
export default Other;
