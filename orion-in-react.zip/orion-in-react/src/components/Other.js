import React, { Component } from "react";
import ckage from "../img/ckage.png";
import fractal from "../img/fractal.png";
import microdot from "../img/microdot.png";
import omnitech from "../img/omnitech.PNG";
import mandelbots from "../img/mandelbots.jpg";
import teamdrift from "../img/teamdrift.PNG";
import Footer from "./Footer";
class Other extends Component {
  render() {
    return (
      <div>
        <h1 className="titlepagetextbottomleft" role="navigation">
          miscellaneous projects
        </h1>
        <div className="sect sectSeven" />
        <div className="mainbody">
          <div className="spacerdiv">
            <h2>But wait, there's more...</h2>
            <p>
              Below you will find an assortment of projects, either small scale,
              headed by an individual on our nonprofit, or independent.
            </p>
          </div>
        </div>
        <div className="row">
          <div className="column projectsCol">
            <div className="centerimages">
              <div className="container1">
                <img alt="tile" src={ckage} className="blockpics" />
                <a
                  href="https://github.com/omnifiedtechnologies/lyzer"
                  className="hovereffect"
                >
                  <div className="text">See Project</div>
                </a>
              </div>
              <div className="container1">
                <img alt="tile" src={fractal} className="blockpics" />
                <a
                  href="https://github.com/simonmahns/fractal"
                  className="hovereffect"
                >
                  <div className="text">See Project</div>
                </a>
              </div>
            </div>
          </div>
          <div className="column projectsCol">
            <div className="centerimages">
              <div className="container1">
                <img alt="tile" src={microdot} className="blockpics" />
                <a
                  href="https://github.com/simonmahns/microdot"
                  className="hovereffect"
                >
                  <div className="text">See Project</div>
                </a>
              </div>
              <div className="container1">
                <img alt="tile" src={omnitech} className="blockpics" />
                <a href="https://omnifiedtech.com" className="hovereffect">
                  <div className="text">See Project</div>
                </a>
              </div>
            </div>
          </div>
          <div className="column projectsCol">
            <div className="container1">
              <img alt="tile" src={mandelbots} className="blockpics" />
              <a href="http://themandelbots.com/" className="hovereffect">
                <div className="text">See Project</div>
              </a>
            </div>
            <div className="container1">
              <img alt="tile" src={teamdrift} className="blockpics" />
              <a
                href="https://www.facebook.com/teamdriftcms/"
                className="hovereffect"
              >
                <div className="text">See Project</div>
              </a>
            </div>
          </div>
        </div>
        <Footer color={"transparent"} />
      </div>
    );
  }
}
export default Other;
