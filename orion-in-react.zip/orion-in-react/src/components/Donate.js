import React, { Component } from "react";

class Donate extends Component {
  render() {
    return (
      <div>
        <h1 className="donatetext">Donate</h1>
        <div className="sect sectOne" />
        <div className="mainbody">
          <div>
            <h2>Help us make a difference</h2>
            <p>
              <i>
                We are currently using PayPal as a way to receive donations
                online. If you wish to donate money to ORION, view the footer of
                this page.
              </i>
              <br />
              <br />
              Below we have a few criteria specifying donor benefits.
              <br />
              <br />
              >1000 USD
              <br /># Logo of your choice on all merchandise/custom materials
              for all projects in which your funds are used
              <br /># Logo displayed on the "sponsors/partners" bar on home
              screen
              <br />
              <br />
              >5000 USD
              <br /># Logo of your choice on all merchandise/custom materials
              for all projects
              <br />
              <i>
                The aforementioned benefits are simply rudimentary. If you have
                any specific benefits you want, contact us to negotiate.{" "}
              </i>
              <br />
              <br />
              Important Notes:
              <br /># Within 6 months of your donation, you will receive an
              email sharing how your funds helped either a person, a group of
              people, or an entire community.
              <br /> #If you would like your donation to be used for a specific
              committee, please let us know through email, our contact form, or
              in the PayPal note section.
            </p>
          </div>
        </div>
      </div>
    );
  }
}
export default Donate;
