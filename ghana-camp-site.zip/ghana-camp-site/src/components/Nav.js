import "./nav.css";
import logo from "../img/menuLogo.png";

import React, { Component } from "react";
import HamburgerMenu from "react-hamburger-menu";

import { Link } from "react-scroll";

class Nav extends Component {
  constructor(props) {
    super(props);
    this.state = { backgroundC: "rgba(0, 0, 0, 0.0)", isOpen: false };
    this.handleScroll = this.handleScroll.bind(this);
    this.handleOpen = this.handleOpen.bind(this);
    this.handleLink = this.handleLink.bind(this);
  }
  componentDidMount() {
    window.addEventListener("scroll", this.handleScroll);
  }

  componentWillUnmount() {
    window.removeEventListener("scroll", this.handleScroll);
  }
  handleScroll() {
    if (window.scrollY < 75) {
      this.setState({ backgroundC: "rgba(0, 0, 0, 0.0)" });
    } else if (window.scrollY >= 75) {
      this.setState({ backgroundC: "rgba(0, 0, 0, 0.5)" });
    }
  }
  handleOpen() {
    this.setState({ isOpen: !this.state.isOpen });
  }

  handleLink() {
    this.setState({ isOpen: false });
  }
  render() {
    const styles = {
      container: {
        position: "fixed",
        top: 0,
        right: this.state.isOpen ? "0px" : "-250px",
        width: "250px",
        height: "100vh",
        display: "flex",
        flexDirection: "column",
        background: "#f0a91a",
        transition: "right 0.3s ease",
        zIndex: 20
      },
      overlay: {
        background: "#000000",
        opacity: 0.1,
        top: 0,
        left: "-250px",
        position: "fixed",
        height: "100vh",
        width: this.state.isOpen ? "100% " : "0px",
        zIndex: 50,
        transition: "width 0.3s ease"
      }
    };
    return (
      <div>
        <div style={styles.overlay} onClick={() => this.handleLink()} />
        <div style={styles.container}>
          <div className="itemContainer">
            <Link
              to="top"
              offset={2}
              smooth={true}
              duration={500}
              className="whiteLink"
            >
              <div className="menuItem" onClick={() => this.handleLink()}>
                <p>top</p>
              </div>
            </Link>
            <Link
              to="faq"
              offset={2}
              smooth={true}
              duration={500}
              className="whiteLink"
            >
              <div className="menuItem" onClick={() => this.handleLink()}>
                <p>Faq</p>
              </div>
            </Link>
            <Link
              to="whatis"
              offset={2}
              smooth={true}
              duration={500}
              className="whiteLink"
            >
              <div className="menuItem" onClick={() => this.handleLink()}>
                <p>what is</p>
              </div>
            </Link>
            <Link
              to="about"
              offset={2}
              smooth={true}
              duration={500}
              className="whiteLink"
            >
              <div className="menuItem" onClick={() => this.handleLink()}>
                <p>about</p>
              </div>
            </Link>
          </div>
        </div>
        <div
          className="header"
          style={{ backgroundColor: this.state.backgroundC }}
        >
          <Link className="reactLink" to="/">
            <img
              src={logo}
              id="fading"
              alt="logo"
              className="logo"
              onClick={() => this.handleLink()}
            />
          </Link>
          <div className="menuImg">
            <HamburgerMenu
              isOpen={this.state.isOpen}
              menuClicked={this.handleOpen.bind(this)}
              width={18}
              height={15}
              rotate={0}
              color="white"
            />
          </div>
        </div>
      </div>
    );
  }
}
export default Nav;
