import React, { Component } from "react";

import insta from "../img/insta.png";
import drive from "../img/drive.png";
import twitter from "../img/twitter.png";

import "./footer.css";

class Footer extends Component {
  constructor(props) {
    super(props);
    this.handleColor = this.handleColor.bind(this);
  }
  handleColor(color) {
    console.log(this.props.color);
    return (
      <div className="innerFootDiv">
        <footer style={{ background: this.props.color }}>
          <div className="footerCont">
            <div className="footerRight">
              <h4>Mission Statement</h4>
              <p>
                Our goal is to bring STEM opportunities to the gifted and driven
                youth of Ghana so that they may execute their full potential.
              </p>
            </div>
            <div className="footerLeft">
              {/* <span>
                <Link
                  
                >
                  <p>{content[0]}</p>
                </Link>
              </span> */}
              <br />

              <span>
                Contact us at{" "}
                <b className="footLink">buildabotghana@gmail.com</b>
              </span>

              <span className="logos">
                <a href="https://www.instagram.com/orionnpo/">
                  <img src={insta} alt="resource" className="logoTiles" />
                </a>
                <a href="https://drive.google.com/drive/folders/1-SYHnm43DWJ8DKxfiklUj3GnIYT-94K4?usp=sharing">
                  <img src={drive} alt="resource" className="logoTiles" />
                </a>
                <a href="https://www.twitter.com/orionnpo/">
                  <img src={twitter} alt="resource" className="logoTiles" />
                </a>
              </span>
            </div>
          </div>
        </footer>
      </div>
    );
  }
  render() {
    var footer = this.handleColor(this.props.color);
    return <div>{footer}</div>;
  }
}
export default Footer;
