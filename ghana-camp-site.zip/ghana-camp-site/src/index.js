import React, { Component } from "react";
import ReactDOM from "react-dom";
import "./index.css";

import background from "./img/footer.jpg";
import landImg from "./img/land3.jpg";
import title from "./img/titleG.png";
import titleW from "./img/titleW.png";

import cal from "./img/calendar.png";
import loc from "./img/placeholder.png";
import lis from "./img/list.png";
import orion from "./img/orion.png";
import stembees from "./img/stembees.png";
import add from "./img/add.png";
import Footer from "./components/Footer";
import Nav from "./components/Nav";

import { BrowserRouter as Router } from "react-router-dom";
import Route from "react-router-dom/Route";

import { Element, Link } from "react-scroll";

class App extends Component {
  render() {
    return (
      <Router>
        <div className="app">
          <Nav />
          <Route
            path="/"
            exact
            strict
            render={() => {
              return (
                <div className="landingPage dBlue">
                  <div
                    className="pageBg"
                    style={{
                      backgroundImage: "url(" + background + ")"
                    }}
                  >
                    <div className="pTextOut">
                      <div className="pTextIn">
                        <Link
                          to="top"
                          className="hover pointer"
                          style={{ width: "100%" }}
                          offset={2}
                          smooth={true}
                          duration={500}
                        >
                          <img className="img" src={titleW} alt="logo" />
                        </Link>
                      </div>
                    </div>
                  </div>
                  <Element
                    name="top"
                    className="landing"
                    style={{
                      backgroundImage: "url(" + landImg + ")"
                    }}
                  >
                    <div className="landingTextDiv">
                      <h1 className="white">JULY 2019</h1>
                    </div>
                  </Element>
                  <Element name="faq" className="mainDiv">
                    <div className="row dynamic">
                      <div className="tri dynamic  center">
                        <img src={cal} className="icon" alt="icon" />
                        <h3>Dates:</h3>
                        <p>2019</p>
                        <p>15 July - 26 July</p>
                        <p>Mon - Fri | 0900 - 1300</p>
                      </div>
                      <div className="tri center  dynamic">
                        <img src={loc} className="icon" alt="icon" />
                        <h3>Location:</h3>
                        <p>University of Ghana in Accra, Ghana</p>
                      </div>
                      <div className="tri center dynamic ">
                        <img src={lis} className="icon" alt="icon" />
                        <h3>Ages:</h3>
                        <p>Anyone attending SHS in September 2019</p>
                      </div>
                    </div>
                  </Element>
                  <Element
                    name="whatis"
                    className="middle"
                    style={{ background: "#ffca61" }}
                  >
                    <div className="mainDiv white ">
                      <div className="row dynamic">
                        <div className="bi dynamic left">
                          <h2 className="title">Come learn about robotics</h2>
                          <p>
                            Build A Bot is a summer camp running in July 2019
                            for high schoolers interested in Robotics and
                            Computer Science. Students of this year's camp will
                            learn the basics of drafting and building lego
                            robots. Student will also be introduced to basic
                            programming logic and will program their own robots.
                            The camp will conclude with a robotics tournament
                            and will include a visit to the beach and talks from
                            professionals from various STEM professions. Price
                            for the camp is 39 USD/200 Cedi.
                          </p>
                        </div>
                        <div className="bi right dynamic centerC">
                          <a href="https://forms.gle/9KdYesTLkayUAdbR9">
                            <img
                              className="img imgRegulate hover"
                              src={title}
                              alt="bottles"
                            />
                          </a>
                        </div>
                      </div>
                    </div>
                  </Element>
                  <Element name="about" className="mainDiv ">
                    <div className="row dynamic">
                      <div className="tri dynamic left">
                        <h2 className="title">A collaborative effort</h2>
                        <p className="">
                          STEM Bees, a Ghana based nonprofit, and ORION, a US
                          based nonprofit, have teamed up to run this camp. This
                          collaboration alongside with the shared previous
                          previous experience running similar camps will make
                          this an event you won't want to miss.{" "}
                        </p>
                      </div>
                      <div className="tri center dynamic">
                        <a className="hover" href="http://www.stembees.org">
                          <img
                            className="img imgRegulate"
                            src={stembees}
                            alt="stembees"
                          />
                        </a>
                        <br />
                        <img className="addIco " src={add} alt="plusIco" />
                        <br />
                        <a className="hover" href="http://omnified.org">
                          <img
                            className="img imgRegulate"
                            src={orion}
                            alt="orion"
                          />
                        </a>
                      </div>
                      <div className="tri dynamic right ">
                        <h2 className="title">About us</h2>
                        <p className="">
                          Both ORION and the STEM Bees are nonprofits. To learn
                          more about each individual organization, see the links
                          below.
                        </p>
                        <br />
                        <div className="hun">
                          <p>
                            <a className="yLink" href="http://www.stembees.org">
                              STEM Bees
                            </a>
                          </p>
                          <p className="padding">|</p>
                          <p>
                            <a className="yLink" href="http://omnified.org">
                              ORION
                            </a>
                          </p>
                        </div>
                      </div>
                    </div>
                  </Element>

                  <Footer language={this.props.language} color={"#ffca61"} />
                </div>
              );
            }}
          />
        </div>
      </Router>
    );
  }
}

export default App;

ReactDOM.render(<App />, document.getElementById("root"));
