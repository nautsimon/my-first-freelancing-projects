import React from "react";

const EmailForm = props => {
  return (
    <form
      onSubmit={props.getEmail}
      method="post"
      target="_blank"
      className="inputarea"
    >
      <input
        onClick={this.getEmail}
        type="email"
        name="email"
        placeholder="YOUR EMAIL"
        className="inputt"
      />
      <input type="submit" value="SUBSCRIBE" className="buttons" />
    </form>
  );
};
export default EmailForm;
