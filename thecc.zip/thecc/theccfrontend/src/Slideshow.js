import React, { Component } from "react";
import { Carousel } from "react-responsive-carousel";
import slide1 from "./img/slide1.PNG";
import slide2 from "./img/slide2.PNG";
import slide3 from "./img/slide3.PNG";
import "react-responsive-carousel/lib/styles/carousel.min.css";

class Slideshow extends Component {
  render() {
    return (
      <Carousel
        autoPlay
        showThumbs={false}
        centerMode
        centerSlidePercentage={40}
        showStatus={false}
        infiniteLoop
        emulateTouch
      >
        <div>
          <a
            className="imgHover"
            href="https://drive.google.com/file/d/1Aox_91Ui8gX27mf82WNs3wjfCo2AC0fF/view?usp=sharing"
          >
            <img src={slide1} alt="slide1" />
          </a>
        </div>
        <div>
          <a
            className="imgHover"
            href="https://drive.google.com/file/d/1Tqob6iGJ9AO_BaZACzcM4EWyj9yYLk_o/view?usp=sharing"
          >
            <img src={slide2} alt="slide2" />
          </a>
        </div>
        <div>
          <a
            className="imgHover"
            href="https://drive.google.com/file/d/1Aox_91Ui8gX27mf82WNs3wjfCo2AC0fF/view?usp=sharing"
          >
            <img src={slide3} alt="slide3" />
          </a>
        </div>
      </Carousel>
    );
  }
}

export default Slideshow;
