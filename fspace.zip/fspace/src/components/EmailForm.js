import React from "react";

const EmailForm = props => {
  return (
    <form
      onSubmit={props.getEmail}
      method="post"
      target="_blank"
      className="inputarea"
    >
      <input
        className="inputFooter"
        onClick={this.getEmail}
        type="email"
        name="email"
        placeholder="Enter Your Email"
      />
      <input type="submit" value="Join Mailing List" className="buttons" />
    </form>
  );
};
export default EmailForm;
