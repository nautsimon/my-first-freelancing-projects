import React, { Component } from "react";
import key1 from "../img/kh/key1.png";
import key2 from "../img/kh/key2.png";
import key3 from "../img/kh/key3.png";
import key4 from "../img/kh/key4.png";
import key5 from "../img/kh/key5.png";
import key6 from "../img/kh/key6.png";
import "./Keyholders.css";
import SkyLight from "react-skylight";

const popupStyle = {
  backgroundColor: "#ffffff",
  minHeight: "200px"
};
let benStyle;
let noahStyle;
let katStyle;
let andrewStyle;
let elaineStyle;
let simonStyle;
var stylin = [
  benStyle,
  noahStyle,
  katStyle,
  andrewStyle,
  elaineStyle,
  simonStyle
];
class Keyholders extends Component {
  constructor(props) {
    super(props);
    this.state = { presentValues: [false, false, false, false, false, false] };
    this.getAttendance();
  }
  getAttendance() {
    console.log("attendance taken");
    for (let i = 0; i < this.state.presentValues.length; i++) {
      if (this.state.presentValues[i]) {
        stylin[i] = { opacity: 1 };
      } else {
        stylin[i] = { opacity: 0.5 };
      }
    }
  }

  render() {
    return (
      <div className="keyholderWrapper">
        <SkyLight
          closeButtonStyle={{ color: "#000" }}
          dialogStyles={popupStyle}
          hideOnOverlayClicked
          ref={ref => (this.benPop = ref)}
          title="Ben"
        >
          Languages: C, C++, Javascript, Python, Ruby, Rust, x86 assembly, Java,
          Html/css, sql, and more. <br />
          Specializes in: cyber security, binary reverse engineering, full stack
          web development, and more.
        </SkyLight>
        <SkyLight
          closeButtonStyle={{ color: "#000" }}
          dialogStyles={popupStyle}
          hideOnOverlayClicked
          ref={ref => (this.noahPop = ref)}
          title="Noah"
        >
          Languages: Python, Java, scratch <br />
          Specializes in: Lock picking.
        </SkyLight>
        <SkyLight
          closeButtonStyle={{ color: "#000" }}
          dialogStyles={popupStyle}
          hideOnOverlayClicked
          ref={ref => (this.katPop = ref)}
          title="Kat"
        >
          Languages: Python, Java, sql, C# <br />
          Specializes in: Front end web Development, Drupal.
        </SkyLight>
        <SkyLight
          closeButtonStyle={{ color: "#000" }}
          dialogStyles={popupStyle}
          hideOnOverlayClicked
          ref={ref => (this.simonPop = ref)}
          title="Simon"
        >
          Languages: Python, Java, Javascript, Html/css, sql, aws, various
          javascript libraries, scratch/nxtg/ev3
          <br />
          Specializes in: Robotics, Full stack Web Development, Raspberry
          pi/Arduino, circuitry, 3D printing/modelling, college advice.
        </SkyLight>
        <SkyLight
          closeButtonStyle={{ color: "#000" }}
          dialogStyles={popupStyle}
          hideOnOverlayClicked
          ref={ref => (this.andrewPop = ref)}
          title="Andrew"
        >
          Languages: Scratch <br /> Specializes in: Lock picking. Scratch.
        </SkyLight>
        <SkyLight
          closeButtonStyle={{ color: "#000" }}
          dialogStyles={popupStyle}
          hideOnOverlayClicked
          ref={ref => (this.elainePop = ref)}
          title="Elaine"
        >
          Languages: Python, Java, Scratch <br /> Specializes in: Lockpicking,
          Scratch.
        </SkyLight>
        <a onClick={() => this.benPop.show()}>
          <img
            src={key1}
            style={stylin[0]}
            className="keyholders"
            alt="keyholder"
          />
        </a>
        <a onClick={() => this.noahPop.show()}>
          <img
            src={key2}
            style={stylin[1]}
            className="keyholders"
            alt="keyholder"
          />
        </a>
        <a onClick={() => this.katPop.show()}>
          <img
            src={key3}
            style={stylin[2]}
            className="keyholders"
            alt="keyholder"
          />
        </a>
        <a onClick={() => this.elainePop.show()}>
          <img
            src={key4}
            style={stylin[3]}
            className="keyholders"
            alt="keyholder"
          />
        </a>
        <a onClick={() => this.andrewPop.show()}>
          <img
            src={key5}
            style={stylin[4]}
            className="keyholders"
            alt="keyholder"
          />
        </a>
        <a onClick={() => this.simonPop.show()}>
          <img
            src={key6}
            style={stylin[5]}
            className="keyholders"
            alt="keyholder"
          />
        </a>
      </div>
    );
  }
}
export default Keyholders;
