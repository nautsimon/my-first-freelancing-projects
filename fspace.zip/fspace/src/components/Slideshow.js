import React, { Component } from "react";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from "react-responsive-carousel";
import slide1 from "../img/slide1.png";
import slide2 from "../img/slide2.png";
import slide3 from "../img/slide3.png";
import slide4 from "../img/slide4.png";
import slide5 from "../img/slide5.png";
import slide6 from "../img/slide6.png";
import slide7 from "../img/slide7.png";
import slide8 from "../img/slide8.png";
import SkyLight from "react-skylight";

const popupStyle = {
  backgroundColor: "#ffffff",
  minHeight: "200px"
};
class Slideshow extends Component {
  render() {
    return (
      <div>
        <SkyLight
          closeButtonStyle={{ color: "#000" }}
          dialogStyles={popupStyle}
          hideOnOverlayClicked
          ref={ref => (this.actoPop = ref)}
          title="Actobotics parts"
        >
          We have mass of Actobotics parts that are useful for general robotics
          projects. This mass includes motors, structure beams, sprockets,
          gears, etc.
        </SkyLight>
        <SkyLight
          closeButtonStyle={{ color: "#000" }}
          dialogStyles={popupStyle}
          hideOnOverlayClicked
          ref={ref => (this.arduinoPop = ref)}
          title="Arduinos"
        >
          We currently have 7 available Arduinos and 2 available raspberry Pis.
        </SkyLight>

        <SkyLight
          closeButtonStyle={{ color: "#000" }}
          dialogStyles={popupStyle}
          hideOnOverlayClicked
          ref={ref => (this.legoPop = ref)}
          title="Lego Mindstorms"
        >
          We have over 8 lego robotics kits for prototyping purposes and
          education purposes for younger makers.
        </SkyLight>
        <SkyLight
          closeButtonStyle={{ color: "#000" }}
          dialogStyles={popupStyle}
          hideOnOverlayClicked
          ref={ref => (this.protoPop = ref)}
          title="Prototyping Tools"
        >
          Jumper cables, Breadboards, etc. We also have various sensors,
          microchips, and miscellaneous hardwares that are useful for all types
          of projects.
        </SkyLight>
        <SkyLight
          closeButtonStyle={{ color: "#000" }}
          dialogStyles={popupStyle}
          hideOnOverlayClicked
          ref={ref => (this.printPop = ref)}
          title="3d printer"
        >
          We have an amateur level 3D priner (Dremmel 3D printer.
        </SkyLight>
        <SkyLight
          closeButtonStyle={{ color: "#000" }}
          dialogStyles={popupStyle}
          hideOnOverlayClicked
          ref={ref => (this.toolPop = ref)}
          title="Tools"
        >
          Your basic tool box. Wrenches, screwdrivers, etc.
        </SkyLight>
        <SkyLight
          closeButtonStyle={{ color: "#000" }}
          dialogStyles={popupStyle}
          hideOnOverlayClicked
          ref={ref => (this.lockPop = ref)}
          title="Lockpicking Instruments"
        >
          We have an array of lockpicking tools and practice locks for your
          disposal.
        </SkyLight>
        <SkyLight
          closeButtonStyle={{ color: "#000" }}
          dialogStyles={popupStyle}
          hideOnOverlayClicked
          ref={ref => (this.wifiPop = ref)}
          title="Wifi"
        >
          Wifi is provided by the law office building fspace is hosted in.
        </SkyLight>

        <Carousel autoPlay interval={3000} showThumbs={false} infiniteLoop>
          <div style={{ background: "#ffffff" }}>
            <img src={slide1} alt="slide" />
            <p onClick={() => this.printPop.show()} className="legend">
              3D printer
            </p>
          </div>
          <div style={{ background: "#ffffff" }}>
            <img src={slide2} alt="slide" />
            <p onClick={() => this.toolPop.show()} className="legend">
              General tools
            </p>
          </div>
          <div style={{ background: "#ffffff" }}>
            <img src={slide3} alt="slide" />
            <p onClick={() => this.arduinoPop.show()} className="legend">
              Arduinos
            </p>
          </div>
          <div style={{ background: "#ffffff" }}>
            <img src={slide4} alt="slide" />
            <p onClick={() => this.protoPop.show()} className="legend">
              Circuit prototyping tools
            </p>
          </div>
          <div style={{ background: "#ffffff" }}>
            <img src={slide5} alt="slide" />
            <p onClick={() => this.actoPop.show()} className="legend">
              Robotics Parts
            </p>
          </div>
          <div style={{ background: "#ffffff" }}>
            <img src={slide6} alt="slide" />
            <p onClick={() => this.lockPop.show()} className="legend">
              Locksport tools
            </p>
          </div>
          <div style={{ background: "#ffffff" }}>
            <img src={slide7} alt="slide" />
            <p onClick={() => this.wifiPop.show()} className="legend">
              Wifi
            </p>
          </div>
          <div style={{ background: "#ffffff" }}>
            <img src={slide8} alt="slide" />
            <p onClick={() => this.legoPop.show()} className="legend">
              LEGO robotics parts
            </p>
          </div>
        </Carousel>
      </div>
    );
  }
}

export default Slideshow;
