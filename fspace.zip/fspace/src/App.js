import React, { Component } from "react";
import "./index.css";
import SceneAlt from "./components/ThreeRenderAlt";

import axios from "axios";
import EmailForm from "./components/EmailForm";
import { TwitterTimelineEmbed } from "react-twitter-embed";

import Slideshow from "./components/Slideshow";
import LazyLoad from "react-lazy-load";
import face from "./img/face.png";
import insta from "./img/insta.png";
import drive from "./img/drive.png";
import twitter from "./img/twitter.png";
import meet from "./img/meet.png";
import meetup from "./img/meetup.png";
import orion from "./img/orionLogo.png";

import SkyLight from "react-skylight";
const popupStyle = {
  backgroundColor: "#ffffff",
  minHeight: "200px"
};
class App extends Component {
  getEmail = e => {
    e.preventDefault();
    var httpResponse = 0;
    var email = e.target.elements.email.value;
    console.log(email);
    axios
      .post(
        "https://w58n6c9t2i.execute-api.us-east-1.amazonaws.com/dev/emails",
        {
          text: email
        }
      )
      .then(
        function(response) {
          httpResponse = response.status;
          alert("Subscribed!");
        },
        () => {
          if (httpResponse !== 200) {
            alert("Failure: make sure your are using an valid email");
          }
        }
      );
  };
  render() {
    return (
      <div className="app">
        <SkyLight
          closeButtonStyle={{ color: "#000" }}
          dialogStyles={popupStyle}
          hideOnOverlayClicked
          ref={ref => (this.khPop = ref)}
          title="Current KH Value"
        >
          This value displays the number of Keyholders present at F[Space].
          F[Space] is open whenever a Keyholder is present. To view the
          Keyholder schedule view our{" "}
          <a
            className="links"
            href="https://calendar.google.com/calendar/embed?src=7ifqcofr70ldeg1308b7aq4j30%40group.calendar.google.com&ctz=America%2FNew_York"
          >
            Google Calendar
          </a>
          . To find out more about each keyholder, view the Keyholder section on
          the homepage.
        </SkyLight>
        {/* <header>
            <nav>
              <ul>
                <li>
                  <span onClick={() => this.khPop.show()} className="coreNum">
                    KH: 0
                  </span> */}
        {/* <NavLink className="coreNum" to="/keyholders">
                    KH: 0
                  </NavLink> */}
        {/* </li>
              </ul>
            </nav>
          </header> */}

        <div>
          <section className="titleWrapper">
            <h2 className="baseTitle">
              <span>We are</span>

              <div className="words titleWords">
                <span className="weAre">F[Space]</span>
                <span className="weAre">a Makerspace</span>
                <span className="weAre">a Hackerspace</span>
                <span className="weAre">a Collaboration place</span>
                <span className="weAre">a study space</span>
              </div>
            </h2>
          </section>
          <div className="body">
            <div className="stretch">
              <SceneAlt />
            </div>
          </div>

          <div className="one">
            <div className="topCross">
              <div className="mainBody">
                <div className="columnWrapper">
                  <div className="leftDiv">
                    <h3>[What is Fspace]</h3>
                    <p>
                      F[Space] is a meetup group intended to cultivate creation
                      and innovation. F[Space] offers free monthly to biweekly
                      classes and hosts a small space located at 151 West
                      Patrick Street. This space has a 3d printer, circuit
                      prototyping tools, and various tools. F[Space] is open by
                      request, on Wednesday nights, and whenever an event is in
                      progress.
                    </p>
                    <h3>[Host your own events]</h3>
                    <p>
                      One of our main goals as a meetup is to cultivate
                      collaboration.
                      <br /> <br />
                      Let's say you wanted to build a drone or start a machine
                      learning project but lacked the manpower and/or expertise.
                      You could simply reach out to one of the staff meetup
                      members via email (fspace@omnified.org) or meetup PM to
                      advertise your project through our meetup. You could set
                      up a first meeting for your project or even just a meetup
                      just to probe for interest. Even if you simply want host a
                      talk or class of your own, or even just want to open the
                      space at a certain time, please contact us as that is what
                      we are here for.
                    </p>
                  </div>

                  <div className="rightDiv">
                    <iframe
                      className="iframeYoutube"
                      title="tedtalk"
                      src="https://www.youtube.com/embed/WkiX7R1-kaY"
                      frameBorder="0"
                      allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    />
                  </div>
                </div>
              </div>
              <div className="middle" style={{ background: "#d9ead3" }}>
                <div className="mainBody">
                  <div className="columnWrapper">
                    <div className="triL">
                      <h3>[Meetup events]</h3>
                      <p>
                        Fspace holds meetup classes and talks monthly and
                        occasionally does so biweekly. Classes/talks are taught
                        by professionals or enthusiasts and are completely free
                        to anyone. Some recent classes we have hosted include, a
                        react js class, a talk about getting into game design,
                        and an introduction to web design.
                      </p>
                    </div>
                    <div className="triC ">
                      <h3>[Upcoming events]</h3>
                      <a href="https://www.meetup.com/fspace">
                        <img className="meetupImg" src={meetup} alt meetup />
                      </a>
                      {/* <div className="widget">
                        
                        https://api.meetup.com/widget?p_width=225&p_urlname=fspace&head=eb20ffc1ccc69ce41599ab455ce077acbe83b8e9&q_groups=231620&name=mug_stats.live.html&p_height=570&q_events=231621&p__name=Meetup+Group+Stats&sig_id=250093949&sig=0f6807280713432ce39cb146f56532cf1e5e44d5
                      </div> */}
                    </div>
                    <div className="triR">
                      <h3>[A Makerspace/Hackerspace]</h3>
                      <p>
                        F[Space] was formed in an effort to create a
                        makerspace/hackerspace community in Frederick. Our
                        current location aims to emulate such a space. Currently
                        we are working with the FITCI effort to create high tier
                        makerspace in downtown frederick in order to fulfill
                        this aspect of the meetup group.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="mainBody">
              <div className="columnWrapper">
                <div className="leftDivTwitter">
                  <LazyLoad offsetVertical={200}>
                    <TwitterTimelineEmbed
                      className="widget"
                      sourceType="profile"
                      screenName="fredmdspace"
                      options={{ height: 500, width: 2000 }}
                    />
                  </LazyLoad>
                </div>

                <div className="rightDiv">
                  <h3>[Stuff we have]</h3>
                  <i className="topPadding">Stuff we have at the space</i>
                  <Slideshow />
                </div>
              </div>
              <h3>[FAQ]</h3>
              <h4>Where is F[Space]?</h4>
              <p>151 West Patrick Street Frederick, MD</p>
              <h4>When can I come in?</h4>
              <p>
                During our events or our open house days, which are Wednesday
                evenings starting at 6pm.
              </p>
              {/* <h4>How can I become a keyholder?</h4> */}
              {/* <p>
                        Keyholder status is acquired through application,
                        interview, and some type of contribution to the space.
                        Contact fspace@omnfied.org if you are interested.
                      </p> */}
              <h4>Use of Tools and Resources</h4>
              <p>
                You do not have to pay the use of any of our resources. However,
                it should be known that F[Space] stays afloat with donations.
                This being said you are not obligated or required in anyways to
                comp your use of tools or 3d printing material, simply suggested
                to do so if you end up depleting a large sum of resources.
              </p>
              <h4>Where can I see pictures?</h4>
              <p>
                {" "}
                Most of our pictures are on Twitter or on our meetup group. We
                plan to also put large albums in our{" "}
                <a
                  className="links"
                  href="https://drive.google.com/drive/folders/1-SYHnm43DWJ8DKxfiklUj3GnIYT-94K4?usp=sharing"
                >
                  public Google Drive Folder
                </a>{" "}
                once we complete larger events, such as the 2019 STEM summer
                camp with HAC.
              </p>
              <h4>
                Still confused? email your questions to fspace@omnfied.org
              </h4>
            </div>
          </div>
        </div>
        <footer>
          <div className="mainBodyFooter">
            <div className="footerContent">
              <div className="columnWrapper">
                <div className="leftDivFooter">
                  <EmailForm getEmail={this.getEmail} />
                  <span>
                    <a href="http://omnified.org">
                      <img src={orion} alt="resource" className="logo" />
                    </a>
                  </span>
                </div>

                <div className="rightDivFooter">
                  <p>Contact us at fspace@omnfied.org</p>
                  <span className="logos">
                    <a href="https://www.instagram.com/orionnpo/">
                      <img src={insta} alt="resource" className="logoTiles" />
                    </a>
                    <a href="https://twitter.com/fredmdspace">
                      <img src={twitter} alt="resource" className="logoTiles" />
                    </a>
                    <a href="https://drive.google.com/drive/folders/1-SYHnm43DWJ8DKxfiklUj3GnIYT-94K4?usp=sharing">
                      <img src={drive} alt="resource" className="logoTiles" />
                    </a>
                    <a href="https://www.facebook.com/frederickmdspace/">
                      <img src={face} alt="resource" className="logoTiles" />
                    </a>
                    <a href="https://www.meetup.com/FSpace/">
                      <img src={meet} alt="resource" className="logoTiles" />
                    </a>
                  </span>

                  <form
                    className="paypal"
                    action="https://www.paypal.com/cgi-bin/webscr"
                    method="post"
                    target="_top"
                  >
                    <input type="hidden" name="cmd" value="_s-xclick" />
                    <input
                      type="hidden"
                      name="hosted_button_id"
                      value="2AXXPJJEEL3K6"
                    />
                    <input
                      type="image"
                      src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_SM.gif"
                      border="0"
                      name="submit"
                      alt="PayPal - The safer, easier way to pay online!"
                    />
                    <img
                      alt=""
                      border="0"
                      src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif"
                      width="1"
                      height="1"
                    />
                  </form>
                </div>
              </div>
            </div>
          </div>
        </footer>
      </div>
    );
  }
}

export default App;
