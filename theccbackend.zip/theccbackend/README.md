# theccbackend
backend for thecc site
made using:
- dynamodb
- aws lambda
- the serverless framework
- api gateway
- node
- j a v a s c r i p t

same code used for the backend of the fspace site
