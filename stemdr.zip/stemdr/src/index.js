import React, { Component } from "react";
import ReactDOM from "react-dom";
import "./index.css";

import AcadRob from "./components/Academiarobotica";
import TheFuture from "./components/TheFuture";
import SkyLight from "react-skylight";
import Particles from "react-particles-js";
import stemdr from "./img/stemdrr.PNG";
import insta from "./img/insta.png";
import drive from "./img/drive.png";
import twitter from "./img/twitter.png";

import orion from "./img/orionLogo.png";

// import Visuals from "./components/Visuals";
// import Scene from "./components/ThreeRender";

import { BrowserRouter as Router, Link } from "react-router-dom";
import Route from "react-router-dom/Route";
const popupStyle = {
  backgroundColor: "#ffffff",
  minHeight: "200px"
};
class App extends Component {
  render() {
    return (
      <Router>
        <div className="app">
          <SkyLight
            closeButtonStyle={{ color: "#000" }}
            dialogStyles={popupStyle}
            hideOnOverlayClicked
            ref={ref => (this.aboutPop = ref)}
            title="About"
          >
            STEM Dominicana is a committee of Omnified Resources for Innovation
            and Cognition Corp (ORION) a 501c3 based in the United States. This
            committee has devoted itself to two primary projects which are
            displayed on this site.
            <br />
            For more about ORION view our{" "}
            <a className="links" href="http://omnified.org">
              website
            </a>
            .
          </SkyLight>
          <Route
            path="/"
            exact
            strict
            render={() => {
              return (
                <div>
                  <Particles
                    className="canvas"
                    params={{
                      particles: {
                        number: {
                          value: 50,
                          density: {
                            enable: true,
                            value_area: 800
                          }
                        },
                        color: {
                          value: "#dddddd"
                        },
                        shape: {
                          type: "circle",
                          stroke: {
                            width: 0,
                            color: "#000000"
                          },
                          polygon: {
                            nb_sides: 6
                          },
                          image: {
                            src: "img/github.svg",
                            width: 100,
                            height: 100
                          }
                        },
                        opacity: {
                          value: 0.5,
                          random: false,
                          anim: {
                            enable: false,
                            speed: 1,
                            opacity_min: 0.1,
                            sync: false
                          }
                        },
                        size: {
                          value: 3,
                          random: true,
                          anim: {
                            enable: false,
                            speed: 40,
                            size_min: 0.1,
                            sync: false
                          }
                        },
                        line_linked: {
                          enable: true,
                          distance: 150,
                          color: "#ffffff",
                          opacity: 0.4,
                          width: 1
                        },
                        move: {
                          enable: true,
                          speed: 3,
                          direction: "none",
                          random: false,
                          straight: false,
                          out_mode: "out",
                          bounce: false,
                          attract: {
                            enable: false,
                            rotateX: 600,
                            rotateY: 1200
                          }
                        }
                      },
                      interactivity: {
                        detect_on: "canvas",
                        events: {
                          onhover: {
                            enable: true,
                            mode: "repulse"
                          },
                          onclick: {
                            enable: true,
                            mode: "push"
                          },
                          resize: true
                        },
                        modes: {
                          grab: {
                            distance: 400,
                            line_linked: {
                              opacity: 1
                            }
                          },
                          bubble: {
                            distance: 200,
                            size: 10,
                            duration: 2,
                            opacity: 8,
                            speed: 3
                          },
                          repulse: {
                            distance: 100,
                            duration: 0.4
                          },
                          push: {
                            particles_nb: 4
                          },
                          remove: {
                            particles_nb: 2
                          }
                        }
                      },
                      retina_detect: true
                    }}
                  />
                  <div className="landing">
                    <div className="titleImgDiv">
                      <img src={stemdr} alt="titleImg" className="titleImg" />
                    </div>
                    <div className="titleYoutubeDiv">
                      <iframe
                        className="titleYoutube"
                        src="https://www.youtube.com/embed/n3GihWdIn4M"
                        frameBorder="0"
                        allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                        title="youtube"
                      />
                    </div>
                  </div>

                  <div className="lpDiv">
                    <div className="columnWrapper">
                      <div className="landLeft">
                        <Link to="/academiarobotica" className="linkStyle">
                          <div className="titleTextDiv">
                            <p className="titleText">ACADEMIA ROBOTICA</p>
                          </div>
                        </Link>
                      </div>
                      <div className="landRight">
                        <a href="#" className="linkStyle">
                          <div className="titleTextDiv">
                            <p className="titleText">YOUTUBE</p>
                            <i className="titleSub">coming soon</i>
                          </div>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              );
            }}
          />
          <Route
            path="/academiarobotica"
            exact
            strict
            render={() => {
              return <AcadRob />;
            }}
          />
          <Route
            path="/thefuture"
            exact
            strict
            render={() => {
              return <TheFuture />;
            }}
          />
          <footer className="frontPageFooter">
            <div className="mainBodyFooter">
              <div className="footerContent">
                <div className="columnWrapper">
                  <div className="leftDivFooter">
                    <span>
                      <a href="http://omnified.org">
                        <img src={orion} alt="resource" className="logo" />
                      </a>
                    </span>
                  </div>

                  <div className="rightDivFooter">
                    <span>
                      <a
                        onClick={() => this.aboutPop.show()}
                        className="footerLinks"
                      >
                        About
                      </a>
                    </span>

                    <p>Contact us at outreach@omnified.org</p>
                    <span className="logos">
                      <a href="https://www.instagram.com/orionnpo/">
                        <img src={insta} alt="resource" className="logoTiles" />
                      </a>
                      <a href="https://drive.google.com/drive/folders/1-SYHnm43DWJ8DKxfiklUj3GnIYT-94K4?usp=sharing">
                        <img src={drive} alt="resource" className="logoTiles" />
                      </a>
                      <a href="https://www.twitter.com/orionnpo/">
                        <img
                          src={twitter}
                          alt="resource"
                          className="logoTiles"
                        />
                      </a>
                    </span>

                    <form
                      className="paypal"
                      action="https://www.paypal.com/cgi-bin/webscr"
                      method="post"
                      target="_top"
                    >
                      <input type="hidden" name="cmd" value="_s-xclick" />
                      <input
                        type="hidden"
                        name="hosted_button_id"
                        value="2AXXPJJEEL3K6"
                      />
                      <input
                        type="image"
                        src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_SM.gif"
                        border="0"
                        name="submit"
                        alt="PayPal - The safer, easier way to pay online!"
                      />
                      <img
                        alt=""
                        border="0"
                        src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif"
                        width="1"
                        height="1"
                      />
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </footer>
        </div>
      </Router>
    );
  }
}

export default App;

ReactDOM.render(<App />, document.getElementById("root"));
