import React, { Component } from "react";
import suit from "../img/suit.png";

import returnImg from "../img/return.png";
import { Link } from "react-router-dom";
import ana from "../img/students/ana.jpg";
import andres from "../img/students/andres.jpg";
import angel from "../img/students/angel.jpg";
import dagna from "../img/students/dagna.jpg";
import dariani from "../img/students/dariani.jpg";
import enam from "../img/students/enam.jpg";
import erick from "../img/students/erick.jpg";
import enmanuelF from "../img/students/enmanuelF.jpg";
import helen from "../img/students/helen.jpg";
import johan from "../img/students/johan.jpg";
import kevin from "../img/students/kevin.jpg";
import mora from "../img/students/mora.jpg";
import suny from "../img/students/suny.jpg";
import wil from "../img/students/wil.jpg";
import SkyLight from "react-skylight";
const popupStyle = {
  backgroundColor: "#ffffff",
  minHeight: "200px"
};

const students = [
  [
    {
      name: "Andres Ernesto Mora Cortorreal",
      grad: 2020,
      school: "Instituto Politecnico Pilar Constanzo.",
      dj: "Mercadotecnia, call center, Electronica.",
      url: andres
    },
    {
      name: "Angel Julio De León Brito",
      grad: 2020,
      school: "Politecnico Cristo Obrero",
      dj: "La Robótica, Electrónica y informática.",
      url: angel
    },
    {
      name: "Dagna Soto",
      grad: 2020,
      school: "instituto Politécnico Pilar Constanzo",
      dj: "Gerente de un restaurante, Bartender, Administradora",
      url: dagna
    },
    {
      name: "Dariani michelle disla pineda ",
      grad: 2020,
      school: "ICentro educativo militar san Miguel arcángel",
      dj: "Informática, mercadeo y ventas, diseño",
      url: dariani
    },
    {
      name: "Enmanuel Pimentel Felix",
      grad: 2020,
      school: "Politecnico Santa Clara de Asís",
      dj: "No se!",
      url: enam
    }
  ],
  [
    {
      name: "Erick Abrahan Betances Guerrero  ",
      grad: 2020,
      school: "Centro de excelencia prof. Luis Encarnacion Nolasco ",
      dj: "Gerente de banco, Dueño de una empresa, Programador ",
      url: erick
    },
    {
      name: "Helen Itmer Agramonte Moreno",
      grad: 2020,
      school: "Instituto Politecnico Hainamosa",
      dj: "Ingeniera química, Programación, Electronica",
      url: helen
    },
    {
      name: "Johan arturo williams",
      grad: 2020,
      school: "Escuela nelda valpiana ",
      dj: "Informatica, ingenieria, programador de redes o sistemas",
      url: johan
    },
    {
      name: "Kismairi Camacho León ",
      grad: 2020,
      school: "Liceo Educación para Pensar ",
      dj: "Arquitectura, Diseño gráfico, Diseño industrial ",
      url: kevin
    },
    {
      name: "Ruth Esther De Jesús Guzmán",
      grad: 2020,
      school: "Instituo Politécnico Pilar Constanzo",
      dj: "En servicio al cliente y cargos administrativos básicos",
      url: ana
    }
  ],
  [
    {
      name: "Sulemny Fernanda Tapia Durán ",
      grad: 2020,
      school: "Politécnico Félix María Ruiz ",
      dj: "Secretaria, Mercadeo,Prof. Informática.",
      url: suny
    },
    {
      name: "Wilzarkys Antonio Vallejo Fernandez",
      grad: 2020,
      school: "Liceo Maria Marcia Comprés ",
      dj: "Administracion de empresas, Contador.",
      url: wil
    },
    {
      name: "Emmanuel Floriano",
      grad: 2020,
      school: "",
      dj: "",
      url: enmanuelF
    },
    {
      name: "Keyla Mora",
      grad: 2020,
      school: "",
      dj: "",
      url: mora
    }
  ]
];
class TheFuture extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "x",
      grad: 2020,
      school: "x",
      dj: "x"
    };
    this.handlePop = this.handlePop.bind(this);
  }
  handlePop(col, val) {
    this.setState(
      {
        name: students[col][val].name,
        grad: students[col][val].grad,
        dj: students[col][val].dj,
        school: students[col][val].school
      },
      this.studentPop.show()
    );
  }
  render() {
    return (
      <div>
        <SkyLight
          closeButtonStyle={{ color: "#000" }}
          dialogStyles={popupStyle}
          hideOnOverlayClicked
          ref={ref => (this.studentPop = ref)}
          title={this.state.name}
        >
          <br />
          <b>Graduation Year:</b> {this.state.grad}
          <br />
          <b>School:</b> {this.state.school}
          <br />
          <b>Intended Professions:</b> {this.state.dj}
        </SkyLight>
        <div className="returnDiv">
          <Link to="/" className="linkStyle">
            <img src={returnImg} alt="return" className="returnIcon" />
          </Link>
        </div>

        <div className="arFive">
          <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br />
          <h2 className="genericText">Presenting the our Alma Mater</h2>
          <div className="columnWrapperAr">
            <div className="tri">
              {students[0].map((student, index) => {
                return (
                  <img
                    alt="biopic"
                    className="bioImgFuture"
                    src={student.url}
                    onClick={() => this.handlePop(0, index)}
                  />
                );
              })}
            </div>
            <div className="tri">
              {students[1].map((student, index) => {
                return (
                  <img
                    alt="biopic"
                    className="bioImgFuture"
                    src={student.url}
                    onClick={() => this.handlePop(1, index)}
                  />
                );
              })}
            </div>
            <div className="tri">
              {students[2].map((student, index) => {
                return (
                  <img
                    alt="biopic"
                    className="bioImgFuture"
                    src={student.url}
                    onClick={() => this.handlePop(2, index)}
                  />
                );
              })}
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default TheFuture;
