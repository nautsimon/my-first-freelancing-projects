import React, { Component } from "react";
import princeton from "../img/princeton.png";
import jpal from "../img/jpal.png";
import arTitle from "../img/arTitle.png";
import futureImg from "../img/future.JPG";
import returnImg from "../img/return.png";
import benj from "../img/benj.jpg";
import max from "../img/max.jpg";
import roberto from "../img/roberto.jpg";
import jaime from "../img/jaime.PNG";
import jose from "../img/jose.PNG";
import simon from "../img/simon.PNG";
import tile17 from "../img/tile17.PNG";
import tile18 from "../img/tile18.jpg";
import vidTile17 from "../img/vidTile17.PNG";
import vidTile18 from "../img/vidTile18.PNG";

import { Link } from "react-router-dom";
class AcadRob extends Component {
  render() {
    return (
      <div>
        <div className="returnDiv">
          <Link to="/" className="linkStyle">
            <img src={returnImg} alt="return" className="returnIcon" />
          </Link>
        </div>
        <img src={arTitle} alt="artitle" className="arTitle" />
        <div className="parallax" />
        <div className="arMain">
          <div className="arOne">
            <div className="columnWrapperAr">
              <div className="leftCol">
                <p className="genericText">
                  Academia Robotica is part of a Princeton University funded,
                  JPAL (Jabul Abdul Latif Poverty Action Lab) study dedicated to
                  determining the effectiveness of various STEM interventions on
                  public school students. Data was collected and amalgamated for
                  the purpose sharing with the Dominican Ministry of Education
                  in hopes of impacting the Dominican curriculum in some way.
                  <br />
                  STEM Dominicana's contributed to this study be creating
                  curriculum and running the camp. STEM Dominicana also assisted
                  in data collection, report writing, and survey creation.
                  <br />
                  For more information view our{" "}
                  <a href="https://docs.google.com/document/d/17eZ_wnh2mdzsTJ7AQ189V_vWVZt4NwVlWrC-2xWWtbk/edit?usp=sharing">
                    2017
                  </a>{" "}
                  and{" "}
                  <a href="https://docs.google.com/document/d/1nGNSKRK0povEJiEdUnns0d6RT-gXmByDjx9rDHelhTc/edit?usp=sharing">
                    2018
                  </a>{" "}
                  reports.
                </p>
              </div>
              <div className="rightCol">
                <h2 className="arSubtitles">Pushing the Boundaries</h2>
              </div>
            </div>
          </div>
          <div className="photosWrapper">
            <h2 className="arSubtitles">Sponsored by/In Conjunction with</h2>
            <div className="photosWrapperWrapper">
              <img src={princeton} className="sponsorPhotos" alt="princeton" />
              <img src={jpal} className="sponsorPhotos" alt="jpal" />
            </div>
          </div>
          {/* the future */}
          <div className="arTwo">
            <div className="columnWrapperAr">
              <div className="leftCol">
                <h2 className="arSubtitles">The Future</h2>
                <p className="arSubSubtitles">Meet the students of the camp</p>
              </div>
              <div className="rightCol">
                <Link to="/thefuture" className="linkStyle">
                  <img src={futureImg} className="photo" alt="futureImg" />
                </Link>
              </div>
            </div>
          </div>
          {/* for student */}
          <div className="arThree">
            <div className="columnWrapperAr">
              <div className="leftCol genericText">
                <h5 align="center" class="aboutheader">
                  Hacer buen uso de su tiempo
                </h5>
                <p lign="center" class="linkssconnect">
                  Si alguna vez necesitas ayuda con algo, uno de los
                  instructores hará todo lo posible para ayudarte, ya sea
                  consejos, mentoría, o incluso ayudarle a iniciar un equipo de
                  robótica. Siempre haremos nuestro mejor esfuerzo para ponerte
                  en el camino correcto.
                </p>

                <h5 class="linksconnect">Networking</h5>
                <p class="linksconnect">
                  <a href="https://www.facebook.com/groups/878372092314397/">
                    facebook
                  </a>
                </p>

                <h5 class="linksconnect">NXT</h5>
                <ul>
                  <li>
                    <p class="linkssconnect">
                      <a href="https://www.lego.com/tr-tr/mindstorms/downloads/nxt-software-download">
                        Descargue el software de programación de NXT
                      </a>
                      : 100% gratis
                    </p>
                  </li>{" "}
                </ul>
                <h5 class="linksconnect">Amplíe sus conocimientos</h5>
                <h5 class="linksconnect">Práctica SAT</h5>
                <ul>
                  <li>
                    <p class="linkssconnect">
                      <a href="https://www.khanacademy.org/sat">
                        Kahn Academy SAT practice
                      </a>
                      : 100% gratis
                    </p>
                  </li>
                </ul>
                <h5 class="linksconnect">
                  Información sobre la aplicación a las escuelas en los Estados
                  Unidos
                </h5>
                <ul>
                  <li>
                    <p class="linkssconnect">
                      <a href="https://docs.google.com/document/d/1_BbIAtKGjVu_-LbLjjL59dqhVNtUqIa3DiY_7iYavYA/edit?usp=sharing">
                        Paquete
                      </a>
                    </p>
                  </li>
                </ul>

                <h5 class="linksconnect">Clases en línea</h5>
                <ul>
                  <li>
                    <p class="linkssconnect">
                      <a href="https://es.khanacademy.org/">Kahn Academy</a>: en
                      español y 100% gratis
                    </p>
                  </li>
                  <li>
                    <p class="linkssconnect">
                      <a href="https://www.coursera.org/">coursera</a>: clases
                      oficiales, puedes imprimir un diploma y todo. Hay miles de
                      temas en Coursera, desde aprender a hacer webs, hasta
                      aprender inglés, este sitio web tiene casi todo lo que
                      necesitas para elevarte
                    </p>
                  </li>
                  <li>
                    <p class="linkssconnect">
                      <a href="https://ocw.mit.edu/index.htm">
                        MIT opencourseware
                      </a>
                      : muchos temas frescos, conferencias crudas
                    </p>
                  </li>
                  <li>
                    <p class="linkssconnect">
                      <a href="http://online-learning.harvard.edu/courses">
                        harvard online classes
                      </a>
                    </p>
                  </li>
                  <li>
                    <p class="linkssconnect">
                      <a href="https://code.org/">code.org</a>: libre y en
                      español, codificación de nivel principiante
                    </p>
                  </li>
                </ul>

                <h51 class="linksconnect">¿Necesita ayuda?</h51>
                <p class="linksconnect">
                  Si alguna vez necesitas ayuda con algo, uno de los
                  instructores hará lo mejor para ayudarte, ya sea adjetivo,
                  mentoría, o incluso ayudar a iniciar un equipo de robótica,
                  haremos nuestro mejor esfuerzo para ponerte en el camino
                  correcto.
                </p>

                <ul>
                  <li>
                    <p class="linkssconnect">Simon: ak.simonm@gmail.com</p>
                  </li>
                  <li>
                    <p class="linkssconnect">Maxine: maxinevidal@gmail.com</p>
                  </li>
                  <li>
                    <p class="linkssconnect">
                      Ben: Benjamin.a.neilson@gmail.com{" "}
                    </p>
                  </li>
                </ul>
              </div>
              <div className="rightCol">
                <h2 className="arSubtitles">Student Area</h2>
              </div>
            </div>
          </div>
          {/* media */}
          <div className="arFour">
            <div className="columnWrapperAr">
              <div className="leftCol">
                <h2 className="arSubtitles">Media</h2>
              </div>
              <div className="rightCol">
                <div className="columnWrapper">
                  <div className="subLeft">
                    <a href="https://drive.google.com/open?id=0B_mRYe-oFVSnWW9xaE80cVRUa2s">
                      <img className="photo" src={tile17} alt="tile17" />
                    </a>
                    <a href="https://www.youtube.com/watch?v=Hc05kBxHefA">
                      <img className="photo" src={vidTile17} alt="tile17" />
                    </a>
                  </div>

                  <div className="subRight">
                    <a href="https://drive.google.com/drive/folders/1sYCo-UlK_2KM-Y0W8ygGmWxRT8zUnULL?usp=sharing">
                      <img className="photo" src={tile18} alt="tile18" />
                    </a>
                    <a href="https://www.youtube.com/watch?v=n3GihWdIn4M">
                      <img className="photo" src={vidTile18} alt="tile18" />
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* intructors */}
          <div className="arFive">
            <br />
            <h2 className="genericText">Instructors</h2>
            <div className="columnWrapperAr">
              <div className="tri">
                <div className="hoverEffectDiv">
                  <img src={benj} className="bioImg" alt="biopic" />
                  <div className="hoverEffect">
                    <p className="bioText">Benjamin Neilson |</p>
                  </div>
                </div>
                <div className="hoverEffectDiv">
                  <img src={jose} className="bioImg" alt="biopic" />
                  <div className="hoverEffect">
                    <p className="bioText"> Jose Alvarez | Carol Morgan</p>
                  </div>
                </div>
              </div>
              <div className="tri">
                <div className="hoverEffectDiv">
                  <img src={max} className="bioImg" alt="biopic" />
                  <div className="hoverEffect">
                    <p className="bioText">
                      Maxine Vidal | Columbia University
                    </p>
                  </div>
                </div>
                <div className="hoverEffectDiv">
                  <img src={jaime} className="bioImg" alt="biopic" />
                  <div className="hoverEffect">
                    <p className="bioText">Jaime Ricart | Carol Morgan</p>
                  </div>
                </div>
              </div>
              <div className="tri">
                <div className="hoverEffectDiv">
                  <img src={roberto} className="bioImg" alt="biopic" />
                  <div className="hoverEffect">
                    <p className="bioText">Roberto Herera | Carol Morgan</p>
                  </div>
                </div>
                <div className="hoverEffectDiv">
                  <img src={simon} className="bioImg" alt="biopic" />
                  <div className="hoverEffect">
                    <p className="bioText">
                      Simon Mahns | The University of Chicago
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default AcadRob;
