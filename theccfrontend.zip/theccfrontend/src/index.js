import React, { Component } from "react";
import ReactDOM from "react-dom";
import "./index.css";

import logo from "./img/logo.png";
import EmailForm from "./components/EmailForm";
import edge from "./img/edge.png";
import remind from "./img/remind.PNG";
import Slideshow from "./Slideshow";
import { BrowserRouter as Router } from "react-router-dom";
import Route from "react-router-dom/Route";
import axios from "axios";

class App extends Component {
  getEmail = e => {
    e.preventDefault();
    var httpResponse = 0;
    var email = e.target.elements.email.value;
    console.log(email);
    axios
      .post(
        "https://9r9h8oxbt0.execute-api.us-east-1.amazonaws.com/dev/emails",
        {
          text: email
        }
      )
      .then(
        function(response) {
          httpResponse = response.status;
          alert("Subscribed!");
        },
        () => {
          if (httpResponse !== 200) {
            alert("Failure: make sure your are using an valid email");
          }
        }
      );
  };

  render() {
    return (
      <Router>
        <div className="app">
          <Route
            path="/"
            exact
            strict
            render={() => {
              return (
                <div>
                  <div className="landing">
                    <header>
                      <div>
                        <img src={logo} alt="logo" className="logo" />
                      </div>
                    </header>
                    <div className="group">
                      <EmailForm getEmail={this.getEmail} />
                    </div>
                  </div>

                  <div className="parallax" />
                  <div className="oner">
                    <div>
                      <img src={edge} alt="edge" className="edge" />
                    </div>
                    <div className="mainBody">
                      <h2>Helping you get where you want to be:</h2>
                      <p>
                        The college communique is an online newsletter dedicated
                        to providing general college application aid and ACT/SAT
                        tips. Our editors and article writers are all highly
                        qualified writers who either attend a prestigious
                        University and/or have scored above the 95th percentile
                        on the ACT/SAT. These students have dedicated hours upon
                        hours to studying for standardized tests and the college
                        application process. Through The College Communique,
                        they aim to share the knowledge that they have accrued
                        through their experience.
                      </p>
                      <h2>Previous Articles</h2>
                      <Slideshow />
                      <h2>About theCC</h2>
                      <p>
                        The College Communique was founded by a ACT perfect
                        scorer Ryan Zhang (Princeton University) and Simon Mahns
                        (University of Chicago) in 2017. Since then, the
                        newsletter has been in incubation as a database of
                        numerous articles have been created. Currently, the
                        newsletter is run by Joshua Yu, a senior at Urbana High
                        School. Our first article will be released in Feburary
                        2019.
                      </p>
                      <h2>Want to get an article published?</h2>
                      <div className="col">
                        <div className="leftcol">
                          <p>
                            TheCC is constantly looking for authors for various
                            articles. To see if you qualify for a writer
                            position, join our remind and an editor will reach
                            out to you. <br />
                          </p>
                        </div>
                        <div className="rightcol">
                          <img src={remind} alt="remind" className="remind" />
                        </div>
                      </div>
                    </div>
                  </div>
                  <footer>
                    <p> © Omnified Technologies LLC 2018</p>
                    <div className="rightcolfoot">
                      <p>Contact us at thecc@omnified.org</p>
                      <span className="footerText">
                        {" "}
                        Proudly presented by{" "}
                        <a href="http://omnified.org">ORION</a>
                      </span>
                    </div>
                  </footer>
                </div>
              );
            }}
          />
        </div>
      </Router>
    );
  }
}

export default App;

ReactDOM.render(<App />, document.getElementById("root"));
