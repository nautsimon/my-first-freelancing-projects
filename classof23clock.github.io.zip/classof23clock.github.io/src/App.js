import React from "react";
import Top from "./components/Top";
import "./App.css";
function App() {
  return (
    <div className="App">
      <Top />
    </div>
  );
}

export default App;
